'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../../lib/supabaseClient';
import { SUBJECTS, CATEGORIES } from '../../lib/subjects';

const EMPTY_FORM = {
  question_text: '',
  option_a: '',
  option_b: '',
  option_c: '',
  option_d: '',
  correct_answer: 'a',
  subject: 'biology',
  category: CATEGORIES.SCIENCE,
};

export default function AdminPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [questions, setQuestions] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const [filterSubject, setFilterSubject] = useState('all');
  const [counts, setCounts] = useState({});

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) { router.replace('/auth'); return; }
      setUser(user);
      loadQuestions();
    });
  }, [router]);

  async function loadQuestions(subject = 'all') {
    setLoading(true);
    let query = supabase.from('questions').select('*').order('created_at', { ascending: false }).limit(50);
    if (subject !== 'all') query = query.eq('subject', subject);

    const { data } = await query;
    setQuestions(data || []);

    // Get counts per subject
    const { data: countData } = await supabase
      .from('questions')
      .select('subject');

    if (countData) {
      const c = {};
      countData.forEach(({ subject }) => {
        c[subject] = (c[subject] || 0) + 1;
      });
      setCounts(c);
    }

    setLoading(false);
  }

  function handleSubjectChange(subjectId) {
    const subject = SUBJECTS.find((s) => s.id === subjectId);
    setForm((f) => ({ ...f, subject: subjectId, category: subject?.category || CATEGORIES.SCIENCE }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    const { error } = await supabase.from('questions').insert([form]);

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Question added successfully!' });
      setForm({ ...EMPTY_FORM, subject: form.subject, category: form.category });
      loadQuestions(filterSubject);
    }
    setSaving(false);
  }

  async function handleDelete(id) {
    if (!confirm('Delete this question?')) return;
    const { error } = await supabase.from('questions').delete().eq('id', id);
    if (!error) loadQuestions(filterSubject);
  }

  const totalQuestions = Object.values(counts).reduce((a, b) => a + b, 0);

  return (
    <main className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-100 sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center text-white font-bold text-sm">SB</div>
            <span className="font-display font-bold text-slate-800">Admin Panel</span>
            <span className="badge bg-amber-100 text-amber-700 ml-1">Questions Manager</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            Total: <strong className="text-slate-800">{totalQuestions}</strong> questions
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-2 gap-6">

          {/* Add Question Form */}
          <div className="card">
            <h2 className="font-display font-bold text-slate-800 text-lg mb-4">Add New Question</h2>

            {message && (
              <div className={`text-sm rounded-xl px-4 py-3 mb-4 ${
                message.type === 'success'
                  ? 'bg-green-50 border border-green-200 text-green-700'
                  : 'bg-red-50 border border-red-200 text-red-700'
              }`}>
                {message.text}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3">
              {/* Subject */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Subject</label>
                <select
                  className="input-field text-sm"
                  value={form.subject}
                  onChange={(e) => handleSubjectChange(e.target.value)}
                >
                  {SUBJECTS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.icon} {s.name} ({counts[s.id] || 0} questions)
                    </option>
                  ))}
                </select>
              </div>

              {/* Question */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Question Text</label>
                <textarea
                  className="input-field text-sm resize-none"
                  rows={3}
                  placeholder="Enter the question..."
                  value={form.question_text}
                  onChange={(e) => setForm((f) => ({ ...f, question_text: e.target.value }))}
                  required
                />
              </div>

              {/* Options */}
              {['a', 'b', 'c', 'd'].map((letter) => (
                <div key={letter}>
                  <label className="block text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">
                    Option {letter.toUpperCase()}
                    {form.correct_answer === letter && (
                      <span className="ml-1.5 text-green-600 normal-case font-normal">(correct)</span>
                    )}
                  </label>
                  <input
                    type="text"
                    className={`input-field text-sm ${form.correct_answer === letter ? 'border-green-400 bg-green-50' : ''}`}
                    placeholder={`Option ${letter.toUpperCase()}`}
                    value={form[`option_${letter}`]}
                    onChange={(e) => setForm((f) => ({ ...f, [`option_${letter}`]: e.target.value }))}
                    required
                  />
                </div>
              ))}

              {/* Correct Answer */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Correct Answer</label>
                <div className="grid grid-cols-4 gap-2">
                  {['a', 'b', 'c', 'd'].map((letter) => (
                    <button
                      key={letter}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, correct_answer: letter }))}
                      className={`py-2 rounded-xl border-2 font-bold text-sm transition-all ${
                        form.correct_answer === letter
                          ? 'border-green-500 bg-green-50 text-green-700'
                          : 'border-slate-200 text-slate-500 hover:border-green-300'
                      }`}
                    >
                      {letter.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <button type="submit" className="btn-primary w-full" disabled={saving}>
                {saving ? 'Saving...' : '+ Add Question'}
              </button>
            </form>
          </div>

          {/* Question List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-display font-bold text-slate-800 text-lg">Questions</h2>
              <select
                className="input-field text-sm py-1.5 w-auto"
                value={filterSubject}
                onChange={(e) => { setFilterSubject(e.target.value); loadQuestions(e.target.value); }}
              >
                <option value="all">All Subjects</option>
                {SUBJECTS.map((s) => (
                  <option key={s.id} value={s.id}>{s.name} ({counts[s.id] || 0})</option>
                ))}
              </select>
            </div>

            {/* Subject counts grid */}
            <div className="grid grid-cols-3 gap-1.5 mb-4">
              {SUBJECTS.slice(0, 9).map((s) => (
                <button
                  key={s.id}
                  onClick={() => { setFilterSubject(s.id); loadQuestions(s.id); }}
                  className={`text-xs p-2 rounded-xl border text-left transition-colors ${
                    filterSubject === s.id ? 'border-brand-400 bg-brand-50 text-brand-700' : 'border-slate-200 bg-white text-slate-600 hover:border-brand-200'
                  }`}
                >
                  <span className="block font-semibold">{counts[s.id] || 0}</span>
                  <span className="text-slate-400">{s.icon} {s.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {loading ? (
                <div className="text-center py-8"><div className="spinner mx-auto" /></div>
              ) : questions.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-sm">No questions found</div>
              ) : (
                questions.map((q) => (
                  <div key={q.id} className="card p-3 text-sm">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-slate-700 font-medium line-clamp-2 mb-1">{q.question_text}</p>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {['a', 'b', 'c', 'd'].map((l) => (
                            <span
                              key={l}
                              className={`text-xs px-1.5 py-0.5 rounded ${
                                q.correct_answer === l
                                  ? 'bg-green-100 text-green-700 font-bold'
                                  : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {l.toUpperCase()}: {q[`option_${l}`]?.slice(0, 15)}{q[`option_${l}`]?.length > 15 ? '…' : ''}
                            </span>
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() => handleDelete(q.id)}
                        className="flex-shrink-0 text-red-400 hover:text-red-600 transition-colors p-1"
                        title="Delete question"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
