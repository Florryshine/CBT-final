'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../../lib/supabaseClient';
import { fetchUserResults } from '../../utils/scoring';
import { getSubjectById, EXAM_CONFIG } from '../../lib/subjects';
import Link from 'next/link';

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    async function init() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.replace('/auth'); return; }
      setUser(user);

      const data = await fetchUserResults(user.id, 20);
      setResults(data);

      // Compute stats
      if (data.length > 0) {
        const avg = Math.round(data.reduce((s, r) => s + r.percentage, 0) / data.length);
        const best = Math.max(...data.map((r) => r.percentage));
        const mockCount = data.filter((r) => r.exam_mode === 'mock').length;
        const singleCount = data.filter((r) => r.exam_mode === 'single').length;
        setStats({ avg, best, total: data.length, mockCount, singleCount });
      }

      setLoading(false);
    }
    init();
  }, [router]);

  async function signOut() {
    await supabase.auth.signOut();
    router.replace('/');
  }

  const gradeColor = (pct) => {
    if (pct >= 80) return 'text-green-600 bg-green-50';
    if (pct >= 65) return 'text-blue-600 bg-blue-50';
    if (pct >= 50) return 'text-brand-600 bg-brand-50';
    if (pct >= 40) return 'text-amber-600 bg-amber-50';
    return 'text-red-600 bg-red-50';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" style={{ width: 40, height: 40, borderWidth: 4 }} />
      </div>
    );
  }

  const displayName = user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Student';

  return (
    <main className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-30">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center text-white font-bold text-sm">SB</div>
            <span className="font-display font-bold text-slate-800">Shiney Brain</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/select-subjects" className="btn-primary text-sm py-2 px-4">
              New Exam
            </Link>
            <button onClick={signOut} className="text-slate-400 hover:text-slate-600 text-sm">
              Sign out
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        {/* Welcome */}
        <div className="animate-slide-up">
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Welcome back, {displayName} 👋
          </h1>
          <p className="text-slate-500 text-sm mt-1">Track your progress and keep practicing</p>
        </div>

        {/* Stats Overview */}
        {stats ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 animate-slide-up">
            {[
              { label: 'Total Exams', value: stats.total, icon: '📝' },
              { label: 'Average Score', value: `${stats.avg}%`, icon: '📊' },
              { label: 'Best Score', value: `${stats.best}%`, icon: '🏆' },
              { label: 'Mock Exams', value: stats.mockCount, icon: '🎯' },
            ].map((s) => (
              <div key={s.label} className="card text-center">
                <div className="text-2xl mb-1">{s.icon}</div>
                <div className="font-display text-xl font-bold text-slate-800">{s.value}</div>
                <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card text-center py-8 animate-fade-in">
            <div className="text-4xl mb-3">🎓</div>
            <h3 className="font-display font-bold text-slate-800 mb-1">No exams yet</h3>
            <p className="text-slate-500 text-sm mb-4">Take your first exam to see your stats here</p>
            <Link href="/select-subjects" className="btn-primary inline-block">
              Start First Exam →
            </Link>
          </div>
        )}

        {/* Recent Results */}
        {results.length > 0 && (
          <div className="animate-fade-in">
            <h2 className="font-display font-bold text-slate-800 mb-3">Recent Exams</h2>
            <div className="space-y-3">
              {results.map((r) => {
                const subjects = r.subjects_selected?.map((id) => getSubjectById(id)).filter(Boolean) || [];
                const examCfg = EXAM_CONFIG[r.exam_mode];
                const date = new Date(r.created_at).toLocaleDateString('en-NG', {
                  day: 'numeric', month: 'short', year: 'numeric',
                });
                return (
                  <div key={r.id} className="card flex items-center gap-4">
                    {/* Score ring */}
                    <div className={`flex-shrink-0 w-14 h-14 rounded-full flex items-center justify-center font-display font-bold text-sm ${gradeColor(r.percentage)}`}>
                      {r.percentage}%
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap gap-1 mb-1">
                        {subjects.slice(0, 3).map((s) => (
                          <span key={s.id} className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                            {s.icon} {s.name.split(' ')[0]}
                          </span>
                        ))}
                        {subjects.length > 3 && (
                          <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">
                            +{subjects.length - 3} more
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500">
                        {r.score}/{r.total_questions} correct · {examCfg?.label || r.exam_mode} · {date}
                      </div>
                    </div>

                    <div className={`flex-shrink-0 text-xs font-bold px-2.5 py-1 rounded-full ${
                      r.percentage >= 50 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'
                    }`}>
                      {r.percentage >= 50 ? 'Pass' : 'Fail'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Quick Start Exam */}
        <div className="card bg-gradient-to-r from-brand-600 to-brand-800 text-white animate-fade-in">
          <h3 className="font-display text-lg font-bold mb-1">Ready to practice?</h3>
          <p className="text-white/70 text-sm mb-4">Pick your subjects and start a new exam now</p>
          <Link href="/select-subjects" className="inline-block bg-white text-brand-700 font-semibold text-sm py-2.5 px-5 rounded-xl hover:bg-brand-50 transition-colors">
            🚀 Start New Exam →
          </Link>
        </div>
      </div>
    </main>
  );
}
