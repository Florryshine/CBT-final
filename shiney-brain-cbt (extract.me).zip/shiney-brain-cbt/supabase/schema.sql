-- ============================================================
-- SHINEY BRAIN JAMB MOCK CBT — Supabase Database Schema
-- Run this in your Supabase SQL editor (Settings → SQL Editor)
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. QUESTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.questions (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  question_text  TEXT NOT NULL,
  option_a       TEXT NOT NULL,
  option_b       TEXT NOT NULL,
  option_c       TEXT NOT NULL,
  option_d       TEXT NOT NULL,
  correct_answer TEXT NOT NULL CHECK (correct_answer IN ('a', 'b', 'c', 'd')),
  subject        TEXT NOT NULL,
  category       TEXT NOT NULL CHECK (category IN ('science', 'arts', 'commercial')),
  year           INTEGER,         -- Optional: JAMB year the question appeared
  difficulty     TEXT DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for efficient filtering
CREATE INDEX IF NOT EXISTS idx_questions_subject  ON public.questions (subject);
CREATE INDEX IF NOT EXISTS idx_questions_category ON public.questions (category);

-- ============================================================
-- 2. RESULTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.results (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  score             INTEGER NOT NULL,
  total_questions   INTEGER NOT NULL,
  percentage        NUMERIC(5,2) NOT NULL,
  exam_mode         TEXT NOT NULL CHECK (exam_mode IN ('single', 'mock')),
  subjects_selected TEXT[] NOT NULL,   -- Array of subject IDs
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast user history lookup
CREATE INDEX IF NOT EXISTS idx_results_user_id    ON public.results (user_id);
CREATE INDEX IF NOT EXISTS idx_results_created_at ON public.results (created_at DESC);

-- ============================================================
-- 3. ROW-LEVEL SECURITY (RLS)
-- ============================================================

-- Questions: anyone authenticated can read
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read questions"
  ON public.questions FOR SELECT
  TO authenticated
  USING (true);

-- Admins (service role) can insert/update/delete questions
-- (This is handled server-side via SERVICE_ROLE_KEY)

-- Results: users can only see and insert their own results
ALTER TABLE public.results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own results"
  ON public.results FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own results"
  ON public.results FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ============================================================
-- 4. SAMPLE QUESTIONS (for testing — add your real bank later)
-- Run this block to seed test data
-- ============================================================

INSERT INTO public.questions (question_text, option_a, option_b, option_c, option_d, correct_answer, subject, category) VALUES

-- ---- BIOLOGY (10 samples) ----
('Which organelle is known as the powerhouse of the cell?', 'Nucleus', 'Ribosome', 'Mitochondria', 'Golgi apparatus', 'c', 'biology', 'science'),
('What is the basic unit of heredity?', 'Chromosome', 'Gene', 'DNA', 'Cell', 'b', 'biology', 'science'),
('Which blood group is the universal donor?', 'AB', 'A', 'B', 'O', 'd', 'biology', 'science'),
('The process by which plants make food using sunlight is called', 'Respiration', 'Transpiration', 'Photosynthesis', 'Digestion', 'c', 'biology', 'science'),
('Which of the following is NOT a function of the liver?', 'Production of bile', 'Detoxification', 'Production of insulin', 'Storage of glycogen', 'c', 'biology', 'science'),
('Osmosis is the movement of water from a region of', 'High solute concentration to low solute concentration', 'Low water potential to high water potential', 'High water potential to low water potential', 'Low solute concentration to high solute concentration', 'c', 'biology', 'science'),
('The scientific study of fungi is called', 'Botany', 'Zoology', 'Mycology', 'Ecology', 'c', 'biology', 'science'),
('Which vitamin is synthesized by the body upon exposure to sunlight?', 'Vitamin A', 'Vitamin B', 'Vitamin C', 'Vitamin D', 'd', 'biology', 'science'),
('DNA replication occurs during which phase of cell division?', 'G1 phase', 'S phase', 'G2 phase', 'M phase', 'b', 'biology', 'science'),
('The fluid-filled sac that surrounds the embryo is the', 'Placenta', 'Amnion', 'Chorion', 'Umbilical cord', 'b', 'biology', 'science'),

-- ---- CHEMISTRY (10 samples) ----
('What is the chemical symbol for Gold?', 'Ag', 'Au', 'Gd', 'Go', 'b', 'chemistry', 'science'),
('The pH of a neutral solution at 25°C is', '0', '7', '14', '1', 'b', 'chemistry', 'science'),
('Which gas is produced when zinc reacts with dilute hydrochloric acid?', 'Oxygen', 'Carbon dioxide', 'Hydrogen', 'Nitrogen', 'c', 'chemistry', 'science'),
('The process of converting liquid to gas is called', 'Condensation', 'Sublimation', 'Evaporation', 'Solidification', 'c', 'chemistry', 'science'),
('How many electrons does a carbon atom have?', '4', '6', '8', '12', 'b', 'chemistry', 'science'),
('Which of the following is a noble gas?', 'Nitrogen', 'Oxygen', 'Argon', 'Chlorine', 'c', 'chemistry', 'science'),
('The chemical formula for water is', 'H2O2', 'HO', 'H2O', 'H3O', 'c', 'chemistry', 'science'),
('What is the valency of Nitrogen?', '1', '2', '3', '4', 'c', 'chemistry', 'science'),
('Which type of bond is formed by the sharing of electrons?', 'Ionic bond', 'Covalent bond', 'Metallic bond', 'Hydrogen bond', 'b', 'chemistry', 'science'),
('Rusting of iron is an example of', 'Physical change', 'Chemical change', 'Nuclear change', 'Phase change', 'b', 'chemistry', 'science'),

-- ---- PHYSICS (10 samples) ----
('What is the SI unit of force?', 'Watt', 'Joule', 'Newton', 'Pascal', 'c', 'physics', 'science'),
('The speed of light in a vacuum is approximately', '3 × 10^6 m/s', '3 × 10^8 m/s', '3 × 10^10 m/s', '3 × 10^4 m/s', 'b', 'physics', 'science'),
('Which law states that every action has an equal and opposite reaction?', 'Newton''s First Law', 'Newton''s Second Law', 'Newton''s Third Law', 'Law of Gravitation', 'c', 'physics', 'science'),
('The energy stored in a stretched rubber band is called', 'Kinetic energy', 'Thermal energy', 'Elastic potential energy', 'Chemical energy', 'c', 'physics', 'science'),
('What is the unit of electrical resistance?', 'Ampere', 'Volt', 'Ohm', 'Watt', 'c', 'physics', 'science'),
('The bending of light as it passes from one medium to another is called', 'Reflection', 'Refraction', 'Diffraction', 'Dispersion', 'b', 'physics', 'science'),
('Which type of wave does not require a medium to travel?', 'Sound waves', 'Water waves', 'Seismic waves', 'Electromagnetic waves', 'd', 'physics', 'science'),
('The frequency of the Nigerian power supply is', '50 Hz', '60 Hz', '100 Hz', '220 Hz', 'a', 'physics', 'science'),
('Ohm''s law states that voltage equals', 'Current × Time', 'Current × Resistance', 'Current / Resistance', 'Power / Current', 'b', 'physics', 'science'),
('The device used to measure electric current is called', 'Voltmeter', 'Galvanometer', 'Ammeter', 'Ohmmeter', 'c', 'physics', 'science'),

-- ---- MATHEMATICS (10 samples) ----
('What is the value of π (pi) to 2 decimal places?', '3.12', '3.14', '3.16', '3.41', 'b', 'mathematics', 'science'),
('If 2x + 5 = 15, what is x?', '2', '4', '5', '10', 'c', 'mathematics', 'science'),
('What is the square root of 144?', '11', '12', '13', '14', 'b', 'mathematics', 'science'),
('The sum of angles in a triangle is', '90°', '180°', '270°', '360°', 'b', 'mathematics', 'science'),
('What is 15% of 200?', '25', '30', '35', '40', 'b', 'mathematics', 'science'),
('Simplify: (3x²)(4x³)', '7x⁵', '12x⁵', '12x⁶', '7x⁶', 'b', 'mathematics', 'science'),
('The area of a circle with radius 7cm is (use π = 22/7)', '44 cm²', '154 cm²', '308 cm²', '616 cm²', 'b', 'mathematics', 'science'),
('What is the LCM of 4, 6, and 8?', '12', '18', '24', '48', 'c', 'mathematics', 'science'),
('If log 2 = 0.3010, find log 8', '0.6020', '0.9030', '1.2040', '2.4080', 'b', 'mathematics', 'science'),
('The gradient of a line passing through (0,0) and (3,6) is', '0.5', '1', '2', '3', 'c', 'mathematics', 'science'),

-- ---- ENGLISH (10 samples) ----
('Choose the correct form: She __ to the market yesterday.', 'go', 'goes', 'went', 'gone', 'c', 'english', 'arts'),
('Which of these is a conjunction?', 'Quickly', 'Beautiful', 'Although', 'Run', 'c', 'english', 'arts'),
('The plural of "child" is', 'Childs', 'Children', 'Childen', 'Child''s', 'b', 'english', 'arts'),
('Which sentence is in the passive voice?', 'John ate the food', 'The food was eaten by John', 'John eats food daily', 'John will eat the food', 'b', 'english', 'arts'),
('Choose the correct spelling:', 'Recieve', 'Recieve', 'Receive', 'Receve', 'c', 'english', 'arts'),
('A word that describes a noun is called', 'Verb', 'Adverb', 'Adjective', 'Preposition', 'c', 'english', 'arts'),
('Which is the correct use of the apostrophe?', 'The boys book', 'The boys'' book', 'The boy''s book', 'The boys book''', 'c', 'english', 'arts'),
('Choose the antonym of "benevolent":', 'Kind', 'Generous', 'Malevolent', 'Charitable', 'c', 'english', 'arts'),
('"She cried crocodile tears." This is an example of', 'Simile', 'Metaphor', 'Hyperbole', 'Idiom', 'd', 'english', 'arts'),
('The figure of speech in "The wind whispered through the trees" is', 'Personification', 'Simile', 'Metaphor', 'Irony', 'a', 'english', 'arts'),

-- ---- ECONOMICS (10 samples) ----
('The study of how households and firms make decisions is', 'Macroeconomics', 'Microeconomics', 'International trade', 'Development economics', 'b', 'economics', 'commercial'),
('A rise in price of a good leads to', 'An increase in demand', 'A decrease in demand', 'No change in demand', 'An increase in supply', 'b', 'economics', 'commercial'),
('Inflation refers to', 'A fall in price level', 'A sustained rise in price level', 'An increase in production', 'A reduction in unemployment', 'b', 'economics', 'commercial'),
('The value of next best alternative forgone is called', 'Profit', 'Revenue', 'Opportunity cost', 'Fixed cost', 'c', 'economics', 'commercial'),
('Which of the following is a merit good?', 'Cigarettes', 'Alcohol', 'Education', 'Gambling', 'c', 'economics', 'commercial'),
('GDP stands for', 'Gross Domestic Product', 'General Development Plan', 'Gross Development Price', 'General Domestic Price', 'a', 'economics', 'commercial'),
('When supply exceeds demand, price will', 'Rise', 'Fall', 'Remain constant', 'Double', 'b', 'economics', 'commercial'),
('The central bank of Nigeria is the', 'Access Bank', 'First Bank', 'CBN', 'UBA', 'c', 'economics', 'commercial'),
('A monopoly market has', 'Many sellers', 'Two sellers', 'One seller', 'No seller', 'c', 'economics', 'commercial'),
('Which factor of production is rewarded with wages?', 'Land', 'Capital', 'Labour', 'Entrepreneur', 'c', 'economics', 'commercial'),

-- ---- GOVERNMENT (10 samples) ----
('The head of government in a presidential system is the', 'Prime Minister', 'President', 'Governor-General', 'Chancellor', 'b', 'government', 'arts'),
('The Nigerian constitution was made effective from', '1 October 1999', '29 May 1999', '1 January 2000', '1 October 2000', 'b', 'government', 'arts'),
('Federalism means power is shared between', 'The president and parliament', 'Central and component units', 'Judiciary and legislature', 'Citizens and government', 'b', 'government', 'arts'),
('The arm of government that makes laws is the', 'Executive', 'Judiciary', 'Legislature', 'Military', 'c', 'government', 'arts'),
('INEC stands for', 'Independent National Electoral Commission', 'Internal National Election Committee', 'Independent Nigeria Election Corporation', 'Integrated National Electoral Council', 'a', 'government', 'arts'),
('In a democracy, sovereignty lies with the', 'President', 'Military', 'People', 'Judiciary', 'c', 'government', 'arts'),
('The process of removing a president from office is called', 'Recall', 'Impeachment', 'Dissolution', 'Suspension', 'b', 'government', 'arts'),
('How many states are in Nigeria?', '30', '34', '36', '38', 'c', 'government', 'arts'),
('The first military coup in Nigeria occurred in', '1960', '1963', '1966', '1970', 'c', 'government', 'arts'),
('Pressure groups differ from political parties in that they', 'Seek to capture power', 'Contest elections', 'Influence government policy without seeking power', 'Are always illegal', 'c', 'government', 'arts'),

-- ---- ACCOUNTING (10 samples) ----
('The accounting equation is', 'Assets = Liabilities – Capital', 'Assets = Liabilities + Capital', 'Capital = Assets + Liabilities', 'Liabilities = Assets + Capital', 'b', 'accounting', 'commercial'),
('Depreciation is the', 'Increase in value of an asset', 'Decrease in value of an asset over time', 'Cost of purchasing an asset', 'Revenue earned from an asset', 'b', 'accounting', 'commercial'),
('Which of these is a current asset?', 'Land', 'Building', 'Cash', 'Motor vehicle', 'c', 'accounting', 'commercial'),
('The document that shows a company''s financial position is the', 'Income statement', 'Balance sheet', 'Cash flow statement', 'Trial balance', 'b', 'accounting', 'commercial'),
('Bad debts are debts that', 'Are paid early', 'Cannot be recovered', 'Are paid in installments', 'Are secured by collateral', 'b', 'accounting', 'commercial'),
('Gross profit equals', 'Revenue minus all expenses', 'Revenue minus cost of goods sold', 'Net profit plus expenses', 'Sales minus net profit', 'b', 'accounting', 'commercial'),
('A credit entry increases', 'Assets', 'Expenses', 'Liabilities', 'Purchases', 'c', 'accounting', 'commercial'),
('The petty cash book records', 'All major cash transactions', 'Small routine cash payments', 'Credit sales only', 'Bank transactions', 'b', 'accounting', 'commercial'),
('Capital expenditure is expenditure on', 'Salaries', 'Long-term assets', 'Daily operations', 'Raw materials', 'b', 'accounting', 'commercial'),
('Which account has a normal debit balance?', 'Sales account', 'Capital account', 'Creditors account', 'Purchases account', 'd', 'accounting', 'commercial'),

-- ---- GEOGRAPHY (10 samples) ----
('The longest river in the world is the', 'Amazon', 'Congo', 'Nile', 'Mississippi', 'c', 'geography', 'commercial'),
('Which of the following is a result of plate tectonics?', 'Rainfall', 'Earthquakes', 'Typhoons', 'Tornadoes', 'b', 'geography', 'commercial'),
('The imaginary line at 0° latitude is called the', 'Prime Meridian', 'Equator', 'Tropic of Cancer', 'Arctic Circle', 'b', 'geography', 'commercial'),
('Nigeria is located in which region of Africa?', 'East Africa', 'North Africa', 'West Africa', 'Southern Africa', 'c', 'geography', 'commercial'),
('The movement of people from rural to urban areas is called', 'Immigration', 'Emigration', 'Urbanization', 'Rural development', 'c', 'geography', 'commercial'),
('The harmattan wind blows from', 'The Atlantic Ocean', 'The Sahara Desert', 'The Indian Ocean', 'The Mediterranean Sea', 'b', 'geography', 'commercial'),
('Limestone is a type of __ rock', 'Igneous', 'Metamorphic', 'Sedimentary', 'Volcanic', 'c', 'geography', 'commercial'),
('The capital of Nigeria is', 'Lagos', 'Kano', 'Abuja', 'Port Harcourt', 'c', 'geography', 'commercial'),
('Population density is calculated as', 'Population × Area', 'Population ÷ Area', 'Area ÷ Population', 'Population + Area', 'b', 'geography', 'commercial'),
('Which natural vegetation is found in southern Nigeria?', 'Desert', 'Savanna', 'Tropical rainforest', 'Tundra', 'c', 'geography', 'commercial'),

-- ---- LITERATURE (5 samples) ----
('The genre that presents a serious subject or the downfall of the main character is called', 'Comedy', 'Tragedy', 'Epic', 'Satire', 'b', 'literature', 'arts'),
('A soliloquy is a speech delivered', 'To another character', 'To the audience alone', 'By the narrator', 'By a group of characters', 'b', 'literature', 'arts'),
('Wole Soyinka was awarded the Nobel Prize in Literature in', '1980', '1983', '1986', '1990', 'c', 'literature', 'arts'),
('The main character in a story is called the', 'Antagonist', 'Narrator', 'Protagonist', 'Foil', 'c', 'literature', 'arts'),
('Which literary device involves a contradiction that reveals a deeper truth?', 'Simile', 'Alliteration', 'Paradox', 'Metaphor', 'c', 'literature', 'arts'),

-- ---- COMMERCE (5 samples) ----
('The practice of buying goods in large quantities and selling in small quantities is', 'Retailing', 'Wholesaling', 'Manufacturing', 'Exporting', 'b', 'commerce', 'commercial'),
('A bill of lading is used in', 'Air transport', 'Road transport', 'Sea transport', 'Rail transport', 'c', 'commerce', 'commercial'),
('E-commerce refers to', 'Commerce in European countries', 'Electronic buying and selling', 'Energy trading', 'Environmental commerce', 'b', 'commerce', 'commercial'),
('A cooperative society is owned by its', 'Government', 'Shareholders', 'Members', 'Directors', 'c', 'commerce', 'commercial'),
('The document sent by a seller to a buyer showing items and prices is a', 'Receipt', 'Invoice', 'Credit note', 'Debit note', 'b', 'commerce', 'commercial'),

-- ---- HISTORY (5 samples) ----
('Nigeria gained independence from Britain on', '1 October 1960', '1 October 1963', '1 January 1960', '27 May 1967', 'a', 'history', 'arts'),
('The Sokoto Caliphate was founded by', 'Sheu Usman Dan Fodio', 'Uthman ibn Affan', 'Mansa Musa', 'Sundiata Keita', 'a', 'history', 'arts'),
('The Trans-Atlantic slave trade primarily involved moving enslaved Africans to', 'Europe', 'Asia', 'The Americas', 'Australia', 'c', 'history', 'arts'),
('The Berlin Conference (1884–85) was about', 'World War I', 'Partitioning Africa among European powers', 'Nuclear weapons', 'Economic cooperation', 'b', 'history', 'arts'),
('The first pan-African conference was held in', '1890', '1900', '1910', '1920', 'b', 'history', 'arts'),

-- ---- CIVIC EDUCATION (5 samples) ----
('The NHRC in Nigeria stands for', 'National Human Rights Commission', 'National Higher Rights Council', 'Nigeria Human Resource Centre', 'National Health Reform Commission', 'a', 'civic_education', 'commercial'),
('Citizens have the right to vote at the age of', '16', '17', '18', '21', 'c', 'civic_education', 'commercial'),
('Which agency is responsible for fighting corruption in Nigeria?', 'NAFDAC', 'EFCC', 'CAC', 'NCC', 'b', 'civic_education', 'commercial'),
('The full meaning of UDHR is', 'United Declaration of Human Rights', 'Universal Declaration of Human Rights', 'United Development of Human Resources', 'Universal Democracy and Human Rights', 'b', 'civic_education', 'commercial'),
('Traffic regulations are enforced by', 'The Army', 'FRSC', 'INEC', 'NCC', 'b', 'civic_education', 'commercial'),

-- ---- MARKETING (5 samples) ----
('The 4Ps of marketing are Product, Price, Place, and', 'Promotion', 'People', 'Process', 'Profit', 'a', 'marketing', 'commercial'),
('Market segmentation means dividing the market into', 'Equal halves', 'Distinct groups of buyers', 'Geographic zones only', 'Price categories', 'b', 'marketing', 'commercial'),
('Brand equity refers to', 'The price of a brand', 'The value added to a product by its brand name', 'The number of products in a brand', 'The location of a brand', 'b', 'marketing', 'commercial'),
('Which promotion strategy uses celebrities?', 'Personal selling', 'Endorsement advertising', 'Public relations', 'Sales promotion', 'b', 'marketing', 'commercial'),
('A SWOT analysis stands for Strengths, Weaknesses, Opportunities, and', 'Trends', 'Targets', 'Threats', 'Tactics', 'c', 'marketing', 'commercial'),

-- ---- CRS (5 samples) ----
('The first book of the Bible is', 'Genesis', 'Exodus', 'Leviticus', 'Numbers', 'a', 'crs', 'arts'),
('Jesus was baptized in the river', 'Euphrates', 'Nile', 'Jordan', 'Tigris', 'c', 'crs', 'arts'),
('The Ten Commandments were given to Moses on Mount', 'Sinai', 'Zion', 'Calvary', 'Carmel', 'a', 'crs', 'arts'),
('The first miracle of Jesus was performed at', 'Jerusalem', 'Cana', 'Bethlehem', 'Nazareth', 'b', 'crs', 'arts'),
('Paul was formerly known as', 'Simon', 'Saul', 'Samuel', 'Solomon', 'b', 'crs', 'arts'),

-- ---- IRS (5 samples) ----
('The holy book of Islam is called', 'Bible', 'Torah', 'Quran', 'Vedas', 'c', 'irs', 'arts'),
('How many pillars of Islam are there?', '3', '4', '5', '6', 'c', 'irs', 'arts'),
('The Prophet of Islam is', 'Ibrahim (AS)', 'Isa (AS)', 'Muhammad (SAW)', 'Musa (AS)', 'c', 'irs', 'arts'),
('Ramadan is the __ month of the Islamic calendar', '8th', '9th', '10th', '12th', 'b', 'irs', 'arts'),
('Zakat refers to', 'Fasting', 'Prayer', 'Almsgiving', 'Pilgrimage', 'c', 'irs', 'arts'),

-- ---- FINE ART (5 samples) ----
('The primary colours are red, blue, and', 'Green', 'Yellow', 'Purple', 'Orange', 'b', 'fine_art', 'arts'),
('The technique of applying thick paint to a surface is called', 'Fresco', 'Impasto', 'Watercolor', 'Mosaic', 'b', 'fine_art', 'arts'),
('A sculpture made by pouring liquid material into a mold is called', 'Carving', 'Modelling', 'Casting', 'Construction', 'c', 'fine_art', 'arts'),
('Ife art is known for its', 'Abstract geometric forms', 'Naturalistic bronze and terracotta works', 'Colour field paintings', 'Cubist sculptures', 'b', 'fine_art', 'arts'),
('Proportion in art refers to', 'The use of colour', 'The size relationship of parts to the whole', 'The texture of a surface', 'The direction of light', 'b', 'fine_art', 'arts');

-- ============================================================
-- USEFUL QUERIES (for reference)
-- ============================================================

-- Check question count per subject:
-- SELECT subject, COUNT(*) as total FROM questions GROUP BY subject ORDER BY subject;

-- Check total questions:
-- SELECT COUNT(*) FROM questions;
